'use client';

import { AppShell, Burger, Group, NavLink, Text, ThemeIcon, ScrollArea } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { useRouter, usePathname } from 'next/navigation';
import { IconWallet, IconListDetails, IconSettings, IconLayoutDashboard, IconFileReport, IconLogout } from '@tabler/icons-react';

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [opened, { toggle }] = useDisclosure();
  const router = useRouter();
  const pathname = usePathname();

  const handleLogout = () => {
    // Logika logout bisa Anda tambahkan di sini nanti
    // Contoh: localStorage.removeItem('user_token');
    
    // Arahkan kembali ke halaman Landing Page / Login
    router.push('/');
  };

  return (
    <AppShell
      header={{ height: 60 }}
      navbar={{ width: 250, breakpoint: 'sm', collapsed: { mobile: !opened } }}
      padding="md"
      styles={{
        main: {
          backgroundColor: 'var(--mantine-color-body)',
        },
      }}
    >
      <AppShell.Header>
        <Group h="100%" px="md">
          <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
          <Text fw={800} size="lg" c="blue.6">CatatUang Pro</Text>
        </Group>
      </AppShell.Header>

      <AppShell.Navbar p="md">
        {/* BAGIAN ATAS: Menu Utama yang akan mengambil ruang kosong dan bisa di-scroll */}
        <AppShell.Section grow component={ScrollArea}>
          <NavLink
            label="Dashboard"
            leftSection={<ThemeIcon variant="light" color="blue"><IconLayoutDashboard size="1rem" /></ThemeIcon>}
            active={pathname === '/dashboard'}
            onClick={() => router.push('/dashboard')}
            mb="sm"
          />
          <NavLink
            label="Dompet & Akun"
            leftSection={<ThemeIcon variant="light" color="teal"><IconWallet size="1rem" /></ThemeIcon>}
            active={pathname.includes('/accounts')}
            onClick={() => router.push('/accounts')}
            mb="sm"
          />
          <NavLink
            label="Jurnal Umum"
            leftSection={<ThemeIcon variant="light" color="grape"><IconListDetails size="1rem" /></ThemeIcon>}
            active={pathname.includes('/transactions')}
            onClick={() => router.push('/transactions')}
            mb="sm"
          />
          <NavLink
            label="Laporan Keuangan"
            leftSection={<ThemeIcon variant="light" color="orange"><IconFileReport size="1rem" /></ThemeIcon>}
            active={pathname.includes('/reports')}
            onClick={() => router.push('/reports')}
            mb="sm"
          />
          <NavLink
            label="Pengaturan"
            leftSection={<ThemeIcon variant="light" color="gray"><IconSettings size="1rem" /></ThemeIcon>}
            active={pathname.includes('/settings')}
            onClick={() => router.push('/settings')}
          />
        </AppShell.Section>

        {/* BAGIAN BAWAH: Akan selalu menempel di dasar Sidebar */}
        <AppShell.Section>
          <NavLink
            label="Keluar (Log Out)"
            leftSection={<ThemeIcon variant="light" color="red"><IconLogout size="1rem" /></ThemeIcon>}
            onClick={handleLogout}
            c="red.7"
            fw={600}
            style={{ borderRadius: 8 }}
          />
        </AppShell.Section>
      </AppShell.Navbar>

      <AppShell.Main>
        {children}
      </AppShell.Main>
    </AppShell>
  );
}