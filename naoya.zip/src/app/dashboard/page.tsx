'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Title, Paper, Text, Group, SimpleGrid, Card, Center, Loader, Badge, Stack, Box, Tooltip } from '@mantine/core';

export default function DashboardPage() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedAccounts = localStorage.getItem('finance_accounts_v3');
    if (savedAccounts) setAccounts(JSON.parse(savedAccounts));

    const savedTransactions = localStorage.getItem('finance_transactions_v2');
    if (savedTransactions) setTransactions(JSON.parse(savedTransactions));

    setIsLoading(false);
  }, []);

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"];

  // ==========================================
  // KALKULASI DATA GLOBAL & PENDAPATAN BULANAN
  // ==========================================
  const globalData = { totalIncome: 0, totalExpense: 0 };
  const monthlyIncomeRaw: Record<string, { label: string; amount: number; sortKey: string }> = {};

  transactions.forEach(trx => {
    if (trx.isDoubleEntry) {
      if (trx.debitOwner === 'Global/Eksternal' || trx.creditOwner === 'Global/Eksternal') {
        const debitName = (trx.debitName || '').toLowerCase();
        const creditName = (trx.creditName || '').toLowerCase();

        // Total Pengeluaran Global
        if (debitName.includes('beban') || debitName.includes('pajak') || debitName.includes('gaji') || debitName.includes('biaya')) {
          globalData.totalExpense += trx.amount;
        } 
        // Total Pendapatan Global & Grafik Bulanan
        else if (creditName.includes('pendapatan') || creditName.includes('bunga')) {
          globalData.totalIncome += trx.amount;

          const dateObj = new Date(trx.date);
          const month = monthNames[dateObj.getMonth()];
          const year = dateObj.getFullYear();
          const sortKey = `${year}-${String(dateObj.getMonth() + 1).padStart(2, '0')}`; 

          if (!monthlyIncomeRaw[sortKey]) {
            monthlyIncomeRaw[sortKey] = { label: `${month} ${year}`, amount: 0, sortKey };
          }
          monthlyIncomeRaw[sortKey].amount += trx.amount;
        }
      }
    } 
  });

  // ==========================================
  // KALKULASI PERTUMBUHAN PENGGUNA BULANAN
  // ==========================================
  const monthlyUsersRaw: Record<string, { label: string; amount: number; sortKey: string }> = {};
  const seenOwners = new Set<string>();

  // Sortir transaksi dari terlama ke terbaru untuk mendapatkan akumulasi pengguna yang akurat
  const sortedTransactions = [...transactions].sort((a, b) => a.date.localeCompare(b.date));

  sortedTransactions.forEach(trx => {
    const dateObj = new Date(trx.date);
    const month = monthNames[dateObj.getMonth()];
    const year = dateObj.getFullYear();
    const sortKey = `${year}-${String(dateObj.getMonth() + 1).padStart(2, '0')}`;
    
    // Hitung pengguna unik
    const checkOwner = (owner: string | null) => {
      if (owner && owner !== 'Global/Eksternal' && owner !== 'MANUAL') {
        seenOwners.add(owner);
      }
    };

    if (trx.isDoubleEntry) {
      checkOwner(trx.debitOwner);
      checkOwner(trx.creditOwner);
    } else {
      const acc = accounts.find(a => a.id === trx.accountId);
      if (acc) checkOwner(acc.owner);
    }

    // Catat jumlah pengguna terdaftar HINGGA bulan tersebut
    monthlyUsersRaw[sortKey] = { label: `${month} ${year}`, amount: seenOwners.size, sortKey };
  });

  // ==========================================
  // FINALISASI DATA GRAFIK (MAKSIMAL 12 BULAN)
  // ==========================================
  const incomeChartData = Object.values(monthlyIncomeRaw).sort((a, b) => a.sortKey.localeCompare(b.sortKey)).slice(-12);
  const maxIncome = Math.max(...incomeChartData.map(d => d.amount), 1); 

  const userChartData = Object.values(monthlyUsersRaw).sort((a, b) => a.sortKey.localeCompare(b.sortKey)).slice(-12);
  const maxUsers = Math.max(...userChartData.map(d => d.amount), 1); 

  const totalAllBalances = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // Fungsi Bantuan untuk menyingkat nominal
  const formatCompactNumber = (number: number) => {
    if (number >= 1000000) return (number / 1000000).toLocaleString('id-ID', { maximumFractionDigits: 1 }) + ' Jt';
    if (number >= 1000) return (number / 1000).toLocaleString('id-ID', { maximumFractionDigits: 1 }) + ' Rb';
    return number.toLocaleString('id-ID');
  };

  if (isLoading) return <DashboardLayout><Center h="50vh"><Loader color="blue" /></Center></DashboardLayout>;

  return (
    <DashboardLayout>
      <Title order={2} mb="lg">Dashboard Eksekutif</Title>

      {/* --- KARTU RINGKASAN ATAS --- */}
      <SimpleGrid cols={{ base: 1, sm: 3 }} spacing="lg" mb="xl">
        <Card withBorder radius="md" padding="xl" shadow="sm">
          <Text size="xs" tt="uppercase" fw={700} c="dimmed">Total Saldo Pokok (Semua Akun)</Text>
          <Text size="xl" fw={800} mt="sm">Rp {totalAllBalances.toLocaleString('id-ID')}</Text>
        </Card>
        <Card withBorder radius="md" padding="xl" shadow="sm" bg="green.0">
          <Text size="xs" tt="uppercase" fw={700} c="green.9">Total Pendapatan Global</Text>
          <Text size="xl" fw={800} c="green.9" mt="sm">Rp {globalData.totalIncome.toLocaleString('id-ID')}</Text>
        </Card>
        <Card withBorder radius="md" padding="xl" shadow="sm" bg="red.0">
          <Text size="xs" tt="uppercase" fw={700} c="red.9">Total Biaya Operasional Global</Text>
          <Text size="xl" fw={800} c="red.9" mt="sm">Rp {globalData.totalExpense.toLocaleString('id-ID')}</Text>
        </Card>
      </SimpleGrid>

      <SimpleGrid cols={{ base: 1, lg: 2 }} spacing="lg">
        
        {/* --- GRAFIK PENDAPATAN GLOBAL BULANAN --- */}
        <Paper withBorder radius="md" p="md" shadow="sm" style={{ display: 'flex', flexDirection: 'column' }}>
          <Group justify="space-between" mb="md">
            <Title order={4}>Tren Pendapatan Global</Title>
            <Badge color="blue" variant="light">Grafik Kinerja</Badge>
          </Group>
          <Text size="sm" c="dimmed" mb="xl">
            Akumulasi Pendapatan Bunga & Eksternal (12 Bulan Terakhir).
          </Text>

          {incomeChartData.length > 0 ? (
            <Group align="flex-end" grow gap="xs" h={250} mt="auto" style={{ borderBottom: '2px solid var(--mantine-color-gray-3)', paddingBottom: '10px' }}>
              {incomeChartData.map((data) => {
                const heightPercentage = (data.amount / maxIncome) * 100;
                return (
                  <Stack key={data.sortKey} align="center" justify="flex-end" gap={0} h="100%">
                    <div style={{ flexGrow: 1, width: '100%', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                      <Tooltip label={`Rp ${data.amount.toLocaleString('id-ID')}`} withArrow position="top">
                        <Box w="100%" maw={40} bg="blue.5" h={`${heightPercentage}%`} style={{ borderRadius: '4px 4px 0 0', cursor: 'pointer', transition: 'height 0.3s ease' }} />
                      </Tooltip>
                    </div>
                    <Text size="11px" fw={800} ta="center" mt={8} c="blue.7" style={{ whiteSpace: 'nowrap' }}>
                      {formatCompactNumber(data.amount)}
                    </Text>
                    <Text size="10px" c="dimmed" fw={600} ta="center" style={{ whiteSpace: 'nowrap' }}>{data.label}</Text>
                  </Stack>
                );
              })}
            </Group>
          ) : (
            <Center h={250}><Text c="dimmed" fs="italic">Belum ada data pendapatan bulanan.</Text></Center>
          )}
        </Paper>

        {/* --- GRAFIK PERTUMBUHAN PENGGUNA --- */}
        <Paper withBorder radius="md" p="md" shadow="sm" style={{ display: 'flex', flexDirection: 'column' }}>
          <Group justify="space-between" mb="md">
            <Title order={4}>Pertumbuhan Pengguna</Title>
            <Badge color="grape" variant="light">Grafik Kinerja</Badge>
          </Group>
          <Text size="sm" c="dimmed" mb="xl">
            Akumulasi jumlah Pemilik / Pengguna terdaftar (12 Bulan Terakhir).
          </Text>

          {userChartData.length > 0 ? (
            <Group align="flex-end" grow gap="xs" h={250} mt="auto" style={{ borderBottom: '2px solid var(--mantine-color-gray-3)', paddingBottom: '10px' }}>
              {userChartData.map((data) => {
                const heightPercentage = (data.amount / maxUsers) * 100;
                return (
                  <Stack key={data.sortKey} align="center" justify="flex-end" gap={0} h="100%">
                    <div style={{ flexGrow: 1, width: '100%', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                      <Tooltip label={`${data.amount} Pengguna`} withArrow position="top">
                        <Box w="100%" maw={40} bg="grape.5" h={`${heightPercentage}%`} style={{ borderRadius: '4px 4px 0 0', cursor: 'pointer', transition: 'height 0.3s ease' }} />
                      </Tooltip>
                    </div>
                    <Text size="11px" fw={800} ta="center" mt={8} c="grape.7" style={{ whiteSpace: 'nowrap' }}>
                      {data.amount}
                    </Text>
                    <Text size="10px" c="dimmed" fw={600} ta="center" style={{ whiteSpace: 'nowrap' }}>{data.label}</Text>
                  </Stack>
                );
              })}
            </Group>
          ) : (
            <Center h={250}><Text c="dimmed" fs="italic">Belum ada data pengguna bulanan.</Text></Center>
          )}
        </Paper>

      </SimpleGrid>
    </DashboardLayout>
  );
}