'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Title, Group, Button, Paper, Text, Table, Badge, Center, Loader, Modal, Stack } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';

const defaultTransactions = [
  { id: 101, accountId: 1, date: '2026-03-20', desc: 'Setoran Awal', amount: 5000000, type: 'INCOME' },
  { id: 102, accountId: 2, date: '2026-03-21', desc: 'Pembayaran Klien A', amount: 15000000, type: 'INCOME' },
  { id: 103, accountId: 2, date: '2026-03-22', desc: 'Bayar Listrik Kantor', amount: 2500000, type: 'EXPENSE' },
  { id: 104, accountId: 3, date: '2026-03-15', desc: 'Gaji Bulanan', amount: 4000000, type: 'INCOME' },
  { id: 105, accountId: 3, date: '2026-03-18', desc: 'Beli Kopi & Makan', amount: 500000, type: 'EXPENSE' },
  { id: 106, accountId: 4, date: '2026-03-01', desc: 'Jatah Belanja Maret', amount: 2000000, type: 'INCOME' },
  { id: 107, accountId: 4, date: '2026-03-05', desc: 'Belanja Sayur & Buah', amount: 500000, type: 'EXPENSE' },
  { id: 108, accountId: 5, date: '2026-03-10', desc: 'Alokasi Server', amount: 800000, type: 'INCOME' },
  { id: 109, accountId: 6, date: '2026-02-28', desc: 'Sisa Uang Jajan', amount: 600000, type: 'INCOME' },
  { id: 110, accountId: 6, date: '2026-03-12', desc: 'Beli Buku Dostoevsky', amount: 150000, type: 'EXPENSE' },
  { id: 111, accountId: 7, date: '2026-03-15', desc: 'Tabungan Awal Liburan', amount: 5000000, type: 'INCOME' },
];

export default function AccountDetailPage() {
  const params = useParams();
  const router = useRouter();
  const accountId = Number(params.id);

  const [account, setAccount] = useState<any>(null);
  const [accountTransactions, setAccountTransactions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [warningOpened, { open: openWarning, close: closeWarning }] = useDisclosure(false);
  const [confirmOpened, { open: openConfirm, close: closeConfirm }] = useDisclosure(false);

  useEffect(() => {
    // Ambil Data Akun
    const savedAccounts = localStorage.getItem('finance_accounts_v3');
    if (savedAccounts) {
      const parsedAccounts = JSON.parse(savedAccounts);
      setAccount(parsedAccounts.find((acc: any) => acc.id === accountId));
    }

    // Ambil Data Transaksi dengan Logika Baru (Support Double-Entry)
    const savedTransactions = localStorage.getItem('finance_transactions_v2');
    if (savedTransactions) {
      const parsedTransactions = JSON.parse(savedTransactions);
      const filtered = parsedTransactions.filter((trx: any) => {
        // Jika format akuntansi (Double-Entry), cek apakah akun ini jadi Debit atau Kredit
        if (trx.isDoubleEntry) {
          return trx.debitId === accountId || trx.creditId === accountId;
        }
        // Format lama
        return trx.accountId === accountId;
      });
      setAccountTransactions(filtered);
    } else {
      localStorage.setItem('finance_transactions_v2', JSON.stringify(defaultTransactions));
      setAccountTransactions(defaultTransactions.filter((trx: any) => trx.accountId === accountId));
    }

    setIsLoading(false);
  }, [accountId]);

  const handleDeleteClick = () => {
    if (account && account.balance > 0) {
      openWarning();
    } else {
      openConfirm();
    }
  };

  const executeDelete = () => {
    const savedAccounts = localStorage.getItem('finance_accounts_v3');
    if (savedAccounts) {
      const parsedAccounts = JSON.parse(savedAccounts);
      localStorage.setItem('finance_accounts_v3', JSON.stringify(parsedAccounts.filter((acc: any) => acc.id !== accountId)));
    }

    // Perlu dihapus juga transaksi double-entry yang melibatkan akun ini
    const savedTransactions = localStorage.getItem('finance_transactions_v2');
    if (savedTransactions) {
      const parsedTransactions = JSON.parse(savedTransactions);
      const updatedTrx = parsedTransactions.filter((trx: any) => {
        if (trx.isDoubleEntry) {
          return trx.debitId !== accountId && trx.creditId !== accountId;
        }
        return trx.accountId !== accountId;
      });
      localStorage.setItem('finance_transactions_v2', JSON.stringify(updatedTrx));
    }

    closeConfirm();
    router.push('/accounts');
  };

  // =========================================================
  // NORMALISASI DATA UNTUK DITAMPILKAN DI TABEL
  // =========================================================
  const displayTransactions = [...accountTransactions].reverse().map((trx) => {
    if (trx.isDoubleEntry) {
      // Jika ID akun ini sama dengan ID Debit, berarti uang masuk (INCOME) ke akun ini
      const isIncoming = trx.debitId === accountId;
      
      // Ambil nama akun lawan (pihak seberang) untuk ditampilkan di deskripsi
      const counterpartName = isIncoming ? trx.creditName : trx.debitName;
      const counterpartOwner = isIncoming ? trx.creditOwner : trx.debitOwner;
      const prefix = isIncoming ? 'Dari: ' : 'Ke: ';
      const ownerText = counterpartOwner && counterpartOwner !== 'Global/Eksternal' ? ` (${counterpartOwner})` : '';
      
      // Menggabungkan deskripsi asli dengan info transfer
      const mainDesc = trx.desc ? `${trx.desc}` : 'Transfer Dana';
      const detailDesc = `${prefix}${counterpartName}${ownerText}`;

      return {
        id: trx.id,
        date: trx.date,
        desc: `${mainDesc} — [${detailDesc}]`,
        type: isIncoming ? 'INCOME' : 'EXPENSE',
        amount: trx.amount
      };
    } else {
      // Jika ini format single-entry lama
      return {
        id: trx.id,
        date: trx.date,
        desc: trx.desc,
        type: trx.type,
        amount: trx.amount
      };
    }
  });

  if (isLoading) return <DashboardLayout><Center h="50vh"><Loader color="blue" /></Center></DashboardLayout>;
  if (!account) return <DashboardLayout><Text c="red" ta="center" mt="xl" fw={600}>Akun tidak ditemukan.</Text><Button mt="md" onClick={() => router.push('/accounts')} mx="auto" display="block">Kembali ke Daftar Simpanan</Button></DashboardLayout>;

  return (
    <DashboardLayout>
      <Group mb="lg">
        <Button variant="subtle" color="gray" onClick={() => router.push('/accounts')}>← Kembali</Button>
      </Group>

      <Paper withBorder p="md" radius="md" mb="xl" shadow="xs">
        <Group justify="space-between">
          <div>
            <Title order={3}>{account.name}</Title>
            <Text c="dimmed" size="sm">Milik: {account.owner}</Text>
          </div>
          <div style={{ textAlign: 'right' }}>
            <Text size="xs" c="dimmed" tt="uppercase" fw={700}>Sisa Saldo</Text>
            <Text size="xl" fw={800} c="blue">Rp {account.balance.toLocaleString('id-ID')}</Text>
          </div>
        </Group>
      </Paper>

      <Group justify="space-between" mb="md">
        <Title order={4}>Riwayat Transaksi</Title>
        <Group>
          <Button color="red" variant="outline" size="sm" onClick={handleDeleteClick}>Hapus Akun</Button>
          <Button color="green" size="sm" onClick={() => router.push(`/accounts/${accountId}/add-transaction`)}>
            + Catat Transaksi
          </Button>
        </Group>
      </Group>

      <Paper withBorder radius="md" p="md">
        {displayTransactions.length > 0 ? (
          <Table verticalSpacing="sm" striped>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Tanggal</Table.Th>
                <Table.Th>Keterangan</Table.Th>
                <Table.Th>Tipe</Table.Th>
                <Table.Th style={{ textAlign: 'right' }}>Jumlah</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {displayTransactions.map((trx) => (
                <Table.Tr key={trx.id}>
                  <Table.Td style={{ whiteSpace: 'nowrap' }}>{trx.date}</Table.Td>
                  <Table.Td>{trx.desc ? <Text size="sm">{trx.desc}</Text> : <Text size="sm" c="dimmed" fs="italic">-</Text>}</Table.Td>
                  <Table.Td>
                    <Badge color={trx.type === 'INCOME' ? 'green' : 'red'} variant="light">
                      {trx.type === 'INCOME' ? 'Masuk' : 'Keluar'}
                    </Badge>
                  </Table.Td>
                  <Table.Td style={{ textAlign: 'right', fontWeight: 600 }}>
                    <Text c={trx.type === 'INCOME' ? 'green' : 'red'} size="sm" fw={600}>
                      {trx.type === 'INCOME' ? '+' : '-'} Rp {trx.amount.toLocaleString('id-ID')}
                    </Text>
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        ) : (
          <Text c="dimmed" fs="italic" ta="center" py="lg">Belum ada transaksi untuk akun ini.</Text>
        )}
      </Paper>

      <Modal opened={warningOpened} onClose={closeWarning} title={<Text fw={700} c="red">Tidak Dapat Menghapus Akun</Text>} centered>
        <Stack>
          <Text size="sm">Anda tidak dapat menghapus <b>{account.name}</b> karena masih memiliki sisa dana sebesar <b>Rp {account.balance.toLocaleString('id-ID')}</b>.</Text>
          <Text size="sm">Harap kosongkan saldo terlebih dahulu sebelum menghapus akun ini.</Text>
          <Button onClick={closeWarning} fullWidth mt="sm">Saya Mengerti</Button>
        </Stack>
      </Modal>

      <Modal opened={confirmOpened} onClose={closeConfirm} title={<Text fw={700} c="red">Konfirmasi Hapus Akun</Text>} centered>
        <Stack>
          <Text size="sm">Apakah Anda yakin ingin menghapus <b>{account.name}</b> secara permanen?</Text>
          <Group justify="flex-end" mt="md">
            <Button variant="default" onClick={closeConfirm}>Batal</Button>
            <Button color="red" onClick={executeDelete}>Ya, Hapus Akun</Button>
          </Group>
        </Stack>
      </Modal>
    </DashboardLayout>
  );
}