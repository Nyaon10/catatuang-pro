'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Title, Paper, Button, TextInput, Select, NumberInput, Stack, Group, Text, Autocomplete } from '@mantine/core';
import { useForm } from '@mantine/form';

export default function AddAccountPage() {
  const router = useRouter();
  const [existingOwners, setExistingOwners] = useState<string[]>([]);

  useEffect(() => {
    const savedAccounts = localStorage.getItem('finance_accounts_v3');
    if (savedAccounts) {
      const parsedAccounts = JSON.parse(savedAccounts);
      const uniqueOwners = Array.from(new Set(parsedAccounts.map((acc: any) => acc.owner))) as string[];
      setExistingOwners(uniqueOwners);
    }
  }, []);

  const form = useForm({
    initialValues: {
      name: '',
      owner: '',
      category: '',
      balance: 0,
      target: 0,
      desc: '', // Properti baru untuk Keterangan
    },
    validate: {
      name: (value) => (value.length < 2 ? 'Nama simpanan terlalu pendek' : null),
      owner: (value) => (value.length < 2 ? 'Nama pemilik wajib diisi' : null),
      category: (value) => (!value ? 'Pilih kategori' : null),
      balance: (value) => 
        (value === undefined || value === null || value < 0) 
          ? 'Saldo awal tidak boleh kosong atau minus' 
          : null,
      target: (value, values) => 
        (['Hobi', 'Tujuan'].includes(values.category) && (value === undefined || value === null || value <= 0))
          ? 'Target saldo harus lebih dari 0'
          : null,
    },
  });

  const handleSubmit = (values: typeof form.values) => {
    const newAccountId = Date.now(); 

    // --- 1. PROSES SIMPAN AKUN ---
    const savedAccounts = localStorage.getItem('finance_accounts_v3');
    const existingAccounts = savedAccounts ? JSON.parse(savedAccounts) : [];

    const isTargetNeeded = ['Hobi', 'Tujuan'].includes(values.category);
    const finalTarget = isTargetNeeded ? values.target : 0;

    const newAccount = {
      id: newAccountId,
      name: values.name,
      owner: values.owner.trim(), 
      category: values.category,
      balance: values.balance,
      target: finalTarget,
    };

    const updatedAccounts = [...existingAccounts, newAccount];
    localStorage.setItem('finance_accounts_v3', JSON.stringify(updatedAccounts));

    // --- 2. PROSES SIMPAN TRANSAKSI OTOMATIS (Jika Saldo > 0) ---
    if (values.balance > 0) {
      const savedTransactions = localStorage.getItem('finance_transactions_v2');
      const existingTransactions = savedTransactions ? JSON.parse(savedTransactions) : [];
      
      const today = new Date().toISOString().split('T')[0];
      
      // LOGIKA DEFAULT KETERANGAN: 
      // Jika form Keterangan (desc) diisi, gunakan itu. Jika di-trim() masih kosong, pakai "Saldo Awal".
      const finalDesc = values.desc.trim() !== '' ? values.desc.trim() : 'Saldo Awal';

      const initialTransaction = {
        id: Date.now() + 1, 
        accountId: newAccountId, 
        date: today,
        desc: finalDesc, // Memasukkan hasil logika default ke sini
        amount: values.balance,
        type: 'INCOME'
      };

      const updatedTransactions = [...existingTransactions, initialTransaction];
      localStorage.setItem('finance_transactions_v2', JSON.stringify(updatedTransactions));
    }

    router.push('/accounts');
  };

  const showTargetInput = ['Hobi', 'Tujuan'].includes(form.values.category);

  return (
    <DashboardLayout>
      <Group mb="lg">
        <Button variant="subtle" color="gray" onClick={() => router.push('/accounts')}>
          ← Kembali
        </Button>
      </Group>

      <Paper withBorder p="xl" radius="md" maw={600} mx="auto" shadow="sm">
        <Title order={3} mb="md">Buat Simpanan Baru</Title>
        <Text c="dimmed" size="sm" mb="xl">
          Isi detail di bawah ini untuk menambahkan kantong simpanan atau rekening baru.
        </Text>

        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack>
            <TextInput 
              label="Nama Simpanan" 
              placeholder="Contoh: Dana Darurat" 
              required 
              {...form.getInputProps('name')} 
            />
            
            <Autocomplete
              label="Nama Pemilik / Entitas"
              placeholder="Pilih dari daftar atau ketik nama baru"
              data={existingOwners}
              required
              {...form.getInputProps('owner')}
            />
            
            <Select 
              label="Kategori" 
              placeholder="Pilih kategori" 
              data={['Darurat', 'Bisnis', 'Pribadi', 'Belanjaan', 'Keperluan', 'Hobi', 'Tujuan']} 
              required 
              {...form.getInputProps('category')} 
            />
            
            <NumberInput 
              label="Saldo Awal (Rp)" 
              placeholder="0" 
              hideControls 
              min={0} 
              required 
              {...form.getInputProps('balance')} 
            />

            {/* Kotak Input Keterangan Baru (Opsional) */}
            <TextInput 
              label="Keterangan Saldo Awal" 
              description="Opsional. Jika dikosongkan, akan terisi 'Saldo Awal' secara otomatis."
              placeholder="Contoh: Sisa THR tahun lalu" 
              {...form.getInputProps('desc')} 
            />
            
            {showTargetInput && (
              <NumberInput 
                label="Target Saldo (Rp)" 
                description="Tentukan target nominal tabungan Anda" 
                placeholder="0" 
                hideControls 
                min={0} 
                required 
                {...form.getInputProps('target')} 
              />
            )}
            
            <Group justify="flex-end" mt="md">
              <Button variant="default" onClick={() => router.push('/accounts')}>Batal</Button>
              <Button type="submit" color="blue">Simpan Akun</Button>
            </Group>
          </Stack>
        </form>
      </Paper>
    </DashboardLayout>
  );
}